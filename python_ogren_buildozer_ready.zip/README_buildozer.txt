Buildozer (APK) notları

1) PC (Linux) veya Termux ortamı gerekir.
   - Pydroid3 tek başına buildozer ile APK derleyemez; Pydroid bir IDE/çalıştırma ortamı.

2) Kurulum (Ubuntu örneği):
   sudo apt update
   sudo apt install -y python3 python3-pip git zip unzip openjdk-17-jdk        autoconf automake libtool pkg-config cmake        libffi-dev libssl-dev
   pip3 install --user buildozer

3) Proje klasöründe:
   buildozer android debug

4) Çıkan APK:
   bin/ klasöründe olur.

Not:
- Bu proje Kivy + KivyMD kullanır.
- KivyMD sürümleri arasında API farkları var; buildozer tarafında farklı bir KivyMD sürümü kurarsan
  küçük UI farkları görebilirsin.
